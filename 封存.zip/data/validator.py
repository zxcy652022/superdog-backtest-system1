"""
Data Validator Module v0.1

功能：驗證 OHLCV CSV 數據的完整性和正確性
檢查項目：欄位、缺漏、數據合理性
"""

import pandas as pd
from datetime import datetime, timedelta
from typing import Dict
import logging

# 設定日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class OHLCVValidator:
    """OHLCV 數據驗證器"""

    REQUIRED_COLUMNS = ['timestamp', 'open', 'high', 'low', 'close', 'volume']

    def __init__(self):
        """初始化驗證器"""
        pass

    def validate_ohlcv_csv(self, file_path: str, timeframe: str = "1h") -> Dict:
        """
        驗證 OHLCV CSV 檔案

        Args:
            file_path: CSV 檔案路徑
            timeframe: 時間框架（用於檢查缺漏），如 '1h'

        Returns:
            Dict: 驗證結果，包含項目
                - ok: bool 是否通過驗證
                - total_rows: int 總列數
                - missing_bars: int 缺少的 K 線數量
                - errors: list 錯誤訊息
                - warnings: list 警告訊息
                - start_date: str 第一筆數據時間
                - end_date: str 最後一筆數據時間

        Raises:
            Exception: 當 CSV 讀取失敗時
        """
        logger.info(f"開始驗證 CSV: {file_path}")

        errors = []
        warnings = []

        try:
            # 讀取 CSV
            df = pd.read_csv(file_path)

            # 1. 檢查欄位是否正確
            missing_columns = set(self.REQUIRED_COLUMNS) - set(df.columns)
            if missing_columns:
                error_msg = f"缺少欄位: {missing_columns}"
                errors.append(error_msg)
                raise Exception(error_msg)

            extra_columns = set(df.columns) - set(self.REQUIRED_COLUMNS)
            if extra_columns:
                warnings.append(f"包含額外欄位: {extra_columns}")

            # 2. 檢查資料型態
            if not pd.api.types.is_numeric_dtype(df['timestamp']):
                errors.append("timestamp 欄位應為數值型態")

            for col in ['open', 'high', 'low', 'close', 'volume']:
                if not pd.api.types.is_numeric_dtype(df[col]):
                    errors.append(f"{col} 欄位應為數值型態")

            # 3. 檢查是否有空值
            null_counts = df.isnull().sum()
            for col, count in null_counts.items():
                if count > 0:
                    warnings.append(f"{col} 欄位有 {count} 個空值")

            # 4. 檢查資料合理性
            if not errors:
                # 檢查 OHLC 邏輯
                invalid_ohlc = df[
                    (df['high'] < df['low']) |
                    (df['high'] < df['open']) |
                    (df['high'] < df['close']) |
                    (df['low'] > df['open']) |
                    (df['low'] > df['close'])
                ]
                if len(invalid_ohlc) > 0:
                    warnings.append(
                        f"發現 {len(invalid_ohlc)} 列 OHLC 邏輯不合理的數據"
                    )

                # 檢查負數價格
                negative_prices = df[
                    (df['open'] <= 0) |
                    (df['high'] <= 0) |
                    (df['low'] <= 0) |
                    (df['close'] <= 0)
                ]
                if len(negative_prices) > 0:
                    errors.append(
                        f"發現 {len(negative_prices)} 列價格為負數或零的數據"
                    )

                # 檢查負數成交量
                negative_volume = df[df['volume'] < 0]
                if len(negative_volume) > 0:
                    errors.append(
                        f"發現 {len(negative_volume)} 列負成交量的數據"
                    )

            # 5. 計算缺少的 K 線數量
            missing_bars = 0
            start_date = ""
            end_date = ""

            if len(df) > 0 and not errors:
                # 排序確保時間順序
                df_sorted = df.sort_values('timestamp')

                # 取得開始和結束時間
                start_ts = df_sorted['timestamp'].iloc[0]
                end_ts = df_sorted['timestamp'].iloc[-1]

                start_date = self._milliseconds_to_date(start_ts)
                end_date = self._milliseconds_to_date(end_ts)

                # 計算時間框架毫秒數
                timeframe_ms = self._timeframe_to_milliseconds(timeframe)

                # 計算理論上應該有的 K 線數量
                expected_bars = int((end_ts - start_ts) / timeframe_ms) + 1
                actual_bars = len(df)
                missing_bars = max(0, expected_bars - actual_bars)

                if missing_bars > 0:
                    warnings.append(
                        f"缺少約 {missing_bars} 根 K 線 "
                        f"(預期: {expected_bars}, 實際: {actual_bars})"
                    )

                # 檢查重複時間戳
                duplicate_ts = df_sorted['timestamp'].duplicated().sum()
                if duplicate_ts > 0:
                    warnings.append(f"發現 {duplicate_ts} 個重複時間戳")

            # 產生結果
            total_rows = len(df)
            ok = len(errors) == 0

            report = {
                "ok": ok,
                "total_rows": total_rows,
                "missing_bars": missing_bars,
                "errors": errors,
                "warnings": warnings,
                "start_date": start_date,
                "end_date": end_date
            }

            # 輸出結果
            if ok:
                logger.info(f"✅ 驗證通過: {file_path}")
                logger.info(f"  總列數: {total_rows}")
                logger.info(f"  缺少 K 線: {missing_bars}")
                logger.info(f"  時間範圍: {start_date} ~ {end_date}")
                if warnings:
                    logger.warning(f"  警告數量: {len(warnings)}")
            else:
                logger.error(f"❌ 驗證失敗: {file_path}")
                logger.error(f"  錯誤: {errors}")

            return report

        except FileNotFoundError:
            error_msg = f"找不到檔案: {file_path}"
            logger.error(error_msg)
            raise Exception(error_msg)

        except pd.errors.EmptyDataError:
            error_msg = f"CSV 檔案為空: {file_path}"
            logger.error(error_msg)
            raise Exception(error_msg)

        except Exception as e:
            if not errors:
                errors.append(str(e))
            logger.error(f"驗證過程發生錯誤: {e}")
            raise

    def _milliseconds_to_date(self, ms: int) -> str:
        """
        毫秒時間戳轉換為日期字串

        Args:
            ms: 毫秒時間戳

        Returns:
            str: 日期字串
        """
        dt = datetime.fromtimestamp(ms / 1000)
        return dt.strftime('%Y-%m-%d %H:%M:%S')

    def _timeframe_to_milliseconds(self, timeframe: str) -> int:
        """
        時間框架轉換為毫秒數

        Args:
            timeframe: 時間框架，如 '1h', '1d'

        Returns:
            int: 毫秒數
        """
        unit = timeframe[-1]
        amount = int(timeframe[:-1])

        unit_ms = {
            'm': 60 * 1000,                    # 分鐘
            'h': 60 * 60 * 1000,               # 小時
            'd': 24 * 60 * 60 * 1000,          # 天
            'w': 7 * 24 * 60 * 60 * 1000,      # 週
        }

        if unit not in unit_ms:
            raise ValueError(f"不支援的時間框架單位: {unit}")

        return amount * unit_ms[unit]


def validate_ohlcv_csv(file_path: str, timeframe: str = "1h") -> Dict:
    """
    便捷函數：驗證 OHLCV CSV 檔案

    Args:
        file_path: CSV 檔案路徑
        timeframe: 時間框架

    Returns:
        Dict: 驗證結果
    """
    validator = OHLCVValidator()
    return validator.validate_ohlcv_csv(file_path, timeframe)


if __name__ == "__main__":
    # 測試驗證
    import sys

    if len(sys.argv) > 1:
        csv_path = sys.argv[1]
    else:
        csv_path = "data/raw/BTCUSDT_1h.csv"

    try:
        report = validate_ohlcv_csv(csv_path)

        print("\n=== 驗證結果 ===")
        print(f"結果: {'✅ 通過' if report['ok'] else '❌ 失敗'}")
        print(f"總列數: {report['total_rows']}")
        print(f"缺少 K 線: {report['missing_bars']}")
        print(f"時間範圍: {report['start_date']} ~ {report['end_date']}")

        if report['errors']:
            print(f"\n錯誤 ({len(report['errors'])}):")
            for error in report['errors']:
                print(f"  - {error}")

        if report['warnings']:
            print(f"\n警告 ({len(report['warnings'])}):")
            for warning in report['warnings']:
                print(f"  - {warning}")

    except Exception as e:
        print(f"驗證失敗: {e}")
        sys.exit(1)
